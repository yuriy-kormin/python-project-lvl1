#!/usr/bin/env python3
from random import randint

def check_even(digit):
    return if digit % 2 ==0

